# Release v100.05 — GitHub workflow deployment and action-runtime hardening

## Exact issue found
The repository's live `main` workflow was still v100.02 and still contained `cache: npm` plus `cache-dependency-path: package.json`. The v100.03 cache-free workflow had not been applied to the repository. This release removes that mismatch by shipping a single authoritative workflow in both `.github/workflows/main.yml` and the standalone YAML file.

## Changes
- Disable setup-node automatic package-manager caching explicitly with `package-manager-cache: false`; no npm lockfile or cache path is required.
- Upgrade GitHub-maintained actions to current major versions supporting the Node 24 action runtime: checkout v7, setup-node v7, setup-java v5, upload-artifact v7.
- Keep the application runtime on Node.js 22; this is separate from the JavaScript runtime used internally by GitHub Actions actions.
- Keep the prior Android SDK fix and exact SDK package installation.
- Add regression checks for the no-cache setting and action versions.
- Bump release version to `2.0.4-v100.05` and Android versionCode to `1099144`.

## Verification
The local JavaScript syntax checks, regression tests, workflow parity, YAML structure, and ZIP integrity are verified before packaging. A real Android APK build still requires the GitHub-hosted runner and must be confirmed by a successful Actions run and uploaded APK artifact.
