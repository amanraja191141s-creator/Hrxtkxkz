# Build verification — v100.05

## Repository mismatch identified
The live repository workflow inspected at `main/.github/workflows/main.yml` was still v100.02. It contained `cache: npm` and `cache-dependency-path: package.json`, which caused `actions/setup-node` to fail because the configured dependency cache path was not a valid lockfile. The previous v100.03 archive was not reflected in the live repository.

## Fix
The authoritative workflow in this release explicitly sets `package-manager-cache: false`, removes all npm cache paths, and updates GitHub-maintained actions to Node 24-compatible major versions. Node.js 22 remains the project build runtime.

## Verification boundary
Source syntax and regression checks are locally verifiable. The Android Gradle build and installable APK upload can only be confirmed by running this workflow on GitHub Actions. No claim of APK compilation is made before that run succeeds.


## Nested repository layout fix
The workflow now discovers the actual SA Calculator project root by locating the matching package.json beneath GITHUB_WORKSPACE. Every app build/test step runs from that resolved directory, so placing the extracted project folder inside the repository no longer causes ENOENT package.json failures.
